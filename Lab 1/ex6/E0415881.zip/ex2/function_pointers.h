/*************************************
* Lab 1 Exercise 2
* Name: Noel Mathew Isaac
* Student No: A0202072Y
* Lab Group: 3
*************************************/

//declare your func_list array here
//remember to add in the keyword - extern
extern int (*func_list[5])(int);
void update_functions();
