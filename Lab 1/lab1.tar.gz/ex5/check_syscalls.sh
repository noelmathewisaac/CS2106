#!/bin/bash

####################
# Lab 1 Exercise 5
# Name:
# Student No:
# Lab Group: 
####################

echo "Printing system call report"

# compile file
gcc -std=c99 pid_checker.c -o ex5

# use strace to get report

