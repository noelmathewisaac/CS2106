/*************************************
* Lab 1 Exercise 2
* Name:
* Student No:
* Lab Group:
*************************************/

#include "functions.h"

// write the necessary code to initialize the func_list
// array here, if needed

void update_functions() 
{
    
}
